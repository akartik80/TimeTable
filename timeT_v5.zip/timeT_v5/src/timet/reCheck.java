/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package timet;

import java.util.List;
import static timet.TimeT2.*;

/**
 *
 * @author molu
 */
public class reCheck {
    public void recheck(Pair mat[][], int level) {
        int i, j, k, m, m1, flag = 0;

        for (i = 0; i < c; i++) {

            for (j = 0; j < t; j++) {

                if (mat[i][j].first > 0) {
                    //flag = 0;
                    for (k = 0; k < 20; k++) {

                        for (m1 = 0; m1 < t; m1++) {
                            if (out[i][m1][k] == 1) {
                                break;
                            }
                        }

                        if (m1 == t) {
                            //System.out.println("free " + " class " + i + " at level " + k);
                            //System.out.println("free class" + i + " at level " + k);

                            List<List<String>> l = class_map.get(classes[i]);

                            int ii;
                            for (ii = 0; ii < l.size(); ii++) {
                                if ((teacher_id.get(l.get(ii).get(2)) - 1) == j) {
                                    break;
                                }
                            }

                            int i1;
                            for (i1 = 2; i1 < l.get(ii).size(); i1++) {

                                for (m = 0; m < c; m++) {
                                    if (out[m][teacher_id.get(l.get(ii).get(i1)) - 1][k] == 1) {
                                        break;
                                    }
                                }
                                if (m != c) {
                                    break;
                                }
                            }
                            if (i1 == l.get(ii).size()) {
                                //System.out.println("Teacher " + j + " assigned to class " + i + " at level " + k);

                                for (i1 = 2; i1 < l.get(ii).size(); i1++) {
                                    out[i][teacher_id.get(l.get(ii).get(i1)) - 1][k] = 1;
                                    out1[i][teacher_id.get(l.get(ii).get(i1)) - 1][k] = teacher_map.get(l.get(ii).get(i1)).get(classes[i]);
                                    mat[i][teacher_id.get(l.get(ii).get(i1)) - 1].first--;
                                    //mat[i][teacher_id.get(l.get(ii).get(i1)) - 1].second = 1;
                                }
                                break;
                            }
                        }
                    }

                }

            }
        }
    }
    
}
