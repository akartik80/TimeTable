/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package timet;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Scanner;
import static timet.TimeT2.*;

public class rgiit {

    public void generateMatrix_rgiit(Pair mat_rgiit[][], Pair mat1_rgiit[][]) {
        int i, j;

        for (String ss : class_map_rgiit.keySet()) {
            List temp = class_map_rgiit.get(ss);

            for (i = 9; i < 12; i++) {
                if (classes[i].equals(ss)) {
                    break;
                }
            }
            System.out.println("hhhhhh");

            int class_id = i;
            //System.out.println("temp size" + temp.size());

            for (i = 0; i < temp.size(); i++) {
                List temp2 = (List) temp.get(i);
                String name = (String) temp2.get(2);
                //System.out.print("name " + name + " ");
                int id = teacher_id.get(name);
                System.out.print(name + " ");
                //System.out.println("id " + id);
                mat_rgiit[class_id][id - 1] = new Pair(Integer.parseInt((String) temp2.get(1)), -1);
                mat1_rgiit[class_id][id - 1] = new Pair(Integer.parseInt((String) temp2.get(1)), -1);
                //System.out.println("setting mat[" + class_id + "][" + (id - 1) + "]");
            }
            System.out.println("");
        }
    }

    public void electives_rgiit() {
        int last = 50;
        int r;
        int flag = 0;

        // 1
        //System.out.println("------------------------------------------------------------------------------------------- entered here at 1 ");
        for (int i = 0; i < basket_it; i++) {
            while (true) {
                r = randomGenerator.nextInt(5);
                //r %= 12; //beacuase there are 20 classes
                if (flag == 0) {
                    break;
                }
                if (r / 4 != last / 4) {
                    break;
                }
            }

            for (String temp : electives_it.keySet()) {
                List<String> l1 = electives_it.get(temp);
                //System.out.println("------------------------------------------------------------------ Size of l1 : " + l1.size());
                //l1 contains subject -> basket, credits, teachers
                System.out.println("------------------------------------------------------------------ the basket is : " + l1.get(0));
                if (l1.get(0).equals((i + 1) + "")) {
                    // 2
                    //System.out.println("----------------------------------------------------------------------------entered here at 2 ");
                    for (int ii = 4 * r; ii < 4 * r + 3; ii++) {
                        for (int kk = 2; kk < l1.size(); kk++) {
                            out[9][teacher_id.get(l1.get(kk)) - 1][ii] = 1; //how to add all the teachers vo teach same subject
                            //System.out.println("-----------------------------------------" + (teacher_id.get(l1.get(kk)) - 1) + " assigned to class ");
                        }
                    }
                }
            }

            flag = 1;
            last = r;
        }
    }

    public void compute_rgiit(Pair mat_rgiit[][], int level) {
        if (level == 5) {
            return;
        }

        int i, j, k;
        boolean ta[] = new boolean[t];

        for (i = 0; i < t; i++) {
            ta[i] = true;
        }

        for (i = 9; i < c; i++) {
            int temp = randomGenerator.nextInt(t - 1);
            int count = 0;

            for (j = temp; count < t; j++, count++) {
                j = (j % t);
                //if (mat_rgiit[i][j].first > 0 && out[i][j][level+3] == 0) {
                //-----------------------------
                if (mat_rgiit[i][j].first > 0 && ta[j] == true) {
                    List<List<String>> l = class_map_rgiit.get(classes[i]);
                    //class_map_rgiit ==  class -> (list of (sub, credit, teachers)
                    int ii;

                    for (ii = 0; ii < l.size(); ii++) {
                        if (j == teacher_id.get(l.get(ii).get(2)) - 1) {
                            break;
                        }
                    }

                    if (ii == l.size()) {
                        System.out.println("Error : Size less");
                    }

                    //System.out.println(i + " here first: " + ii);
                    int ij;
                    //System.out.println("ii : " + ii + " - " + classes[i] + " -- " + l.get(ii).get(0));
                    for (ij = 2; ij < l.get(ii).size(); ij++) {
                        if (ta[teacher_id.get(l.get(ii).get(ij)) - 1] == false) {
                            break;
                        }
                    }

                    //System.out.println("here : " + ij);
                    if (ij != l.get(ii).size()) {
                        continue;
                    }

                    for (ij = 2; ij < l.get(ii).size(); ij++) {
                        ta[teacher_id.get(l.get(ii).get(ij)) - 1] = false;
                        for (int uu = 4 * level; uu < 4 * level + 3; uu++) {
                            out[i][teacher_id.get(l.get(ii).get(ij)) - 1][uu] = 1;
                            System.out.println("-----------------------------------------" + (teacher_id.get(l.get(ii).get(ij)) - 1) + " assigned to class ");
                        }
                        //out[i][teacher_id.get(l.get(ii).get(ij)) - 1][level] = 1;
                    }
                    //&& ta[j] == true 
                    //-----------------------------
                    mat_rgiit[i][j].first = 0;
                    //ta[j] = false;
                    mat_rgiit[i][j].second = (level / 4) * 4 + 4;
                    //System.out.println("i : " + i + " j : " + j + " level : " + level);
                    //out[i][j][level] = 1;
                    break;
                }
            }
        }
        compute_rgiit(mat_rgiit, level + 1);
    }

    public void generateMapping_rgiit() throws FileNotFoundException {
        Scanner sc = new Scanner(new File("inputfile_rgiit.txt"));
        int i, j;

        String line, tmp_s = "aaa";
        List<String> l;
        List< List<String>> ll = new ArrayList<>();
        int flag = 0;

        while (sc.hasNextLine()) {
            line = sc.nextLine();

            String tmp[] = line.split("\t");
            l = new ArrayList<>();

            if (!tmp_s.equals(tmp[0])) {
                if (flag == 0) {
                    flag = 1;
                } else {
                    class_map_rgiit.put(tmp_s, ll);
                }
                ll = new ArrayList<>();
                tmp_s = tmp[0];
            }

            for (i = 1; i < tmp.length; i++) {
                l.add(tmp[i].trim().toLowerCase());
            }

            ll.add(l);
        }
        class_map_rgiit.put(tmp_s, ll);

        //System.out.println("Hello yovan");
    }

    public void generateLabMap_rgiit() throws FileNotFoundException {
        Scanner sc = new Scanner(new File("labinput_rgiit.txt"));
        int i, j;

        String line, tmp_s = "aaa";
        List<String> l;
        List< List<String>> ll = new ArrayList<>();
        int flag = 0;

        while (sc.hasNextLine()) {
            line = sc.nextLine();

            String tmp[] = line.split("\t");
            l = new ArrayList<>();

            if (!tmp_s.equals(tmp[0])) {
                if (flag == 0) {
                    flag = 1;
                } else {
                    lab_map_rgiit.put(tmp_s, ll);
                }
                ll = new ArrayList<>();
                tmp_s = tmp[0];
            }

            for (i = 1; i < tmp.length; i++) {
                l.add(tmp[i].trim().toLowerCase());
            }

            ll.add(l);
        }
        lab_map_rgiit.put(tmp_s, ll);
    }

    public void buildTeacherMap_rgiit() {
        int i, j, k;

//        for (i = 0; i < t; i++) {
//            teacher_map.put(id_teacher.get(i+1), temp);
//        }
        for (String s : class_map_rgiit.keySet()) {
            List<List<String>> kk;
            kk = class_map_rgiit.get(s);

            for (j = 0; j < kk.size(); j++) {
                List<String> l = kk.get(j);
                //System.out.println(l);

                for (k = 2; k < l.size(); k++) {
                    //System.out.print(l.get(k) + " ");
                    //temp.clear();

                    if (teacher_map_rgiit.containsKey(l.get(k))) {
                        HashMap<String, String> tmp = teacher_map_rgiit.get(l.get(k));

                        if (!tmp.containsKey(s)) {
                            tmp.put(s, l.get(0));
                        } else {
                            tmp.replace(s, l.get(0));
                        }
                        //temp.put(s, l.get(0));
                        //System.out.println(s + " -- " + temp.size() + " __ " + l.get(0) + " , " + l.get(k));
                        //teacher_map.replace(l.get(k), temp);

                        teacher_map_rgiit.replace(l.get(k), tmp);
                    } else {
                        HashMap<String, String> tmp = new LinkedHashMap<>();

                        tmp.put(s, l.get(0));

                        teacher_map_rgiit.put(l.get(k), tmp);
                    }
                }

            }
            //System.out.println("");
        }

        for (String s : teacher_map_rgiit.keySet()) {
            teacher_map_rgiit.get(s).remove("__");
        }

//        for (String s : teacher_map.keySet()) {
//            //System.out.println(teacher_map.get(s).size());
//            for (String s1 : teacher_map.get(s).keySet()) {
//                System.out.println(s + " -> " + s1 + " : " + teacher_map.get(s).get(s1));
//            }
//            
//        }
    }

    public void print_rit() {
        for (int i = 9; i < 12; i++) {
            for (int k = 0; k < 20; k++) {
                for (int j = 0; j < 51; j++) {
                    if (out[i][j][k] != 0) {
                        System.out.println("days is : " + days[k / 4] + " teacher is : " + id_teacher.get(j + 1) + " class is : " + classes[i]);
                    }
                }
            }
        }
    }

}
