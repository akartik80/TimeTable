package timet;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import static timet.GUI.time;
import static timet.Teach.teachers;

public class TimeT2 {

    public static int out[][][];           // (c x t x 20)
    public static String out1[][][];       // similar to out -> gives subject
    public static int free_classes;
    public static List out_new[][];        // class x level list of teachers (c x 20) 
    public static List out_new1[][];       // similar to out_new -> gives subject
    public static List lab_new[][];        // lab x level list of teachers (c x 5)
    public static List tt[][];             // teacher x level list of classes (t * 20)
    public static List tt_lab[][];
    public static int lab[][][];           // c * t * 5
    public static int c, t;
    public static String[] days = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday"};
    public static Random randomGenerator = new Random();
    public static List it= new ArrayList<>();
    public static List ece = new ArrayList<>();
    public static HashMap<String, List< List<String>>> class_map = new HashMap<>();  //class -> (list of (sub, credit, teachers)
    public static HashMap<String, HashMap<String, String>> teacher_map = new LinkedHashMap<>();  //teacher -> (list of (class, subject)
    public static HashMap<Integer, String> id_teacher = new HashMap<>();       //id - > teacher
    public static HashMap<String, Integer> teacher_id = new HashMap<>();       //teacher -> id
    public static HashMap<String, List< List<String>>> lab_map = new HashMap<>(); // similar to class_map
    public static HashMap<String, HashMap<String, String>> teacher_lab_map = new LinkedHashMap<>();

    public static int basket_it, basket_ece;           // no of baskets
    public static List<Integer> sub_IT_basket, sub_ECE_basket;     // number of subjects in each basket
    //public static HashMap<Integer, List<List<String>>> electives_it, electives_ece;
    public static HashMap<String, List<String>> electives_it = new HashMap<>();    // list of elective subjects (eg ML -> #basketno., credits, teachers list)
    //this conatins Subject -> (basket , credit, Teacher)
    public static HashMap<String, List<String>> electives_ece = new HashMap<>();   // similar to electives_it

    public static String[] classes = {"3A", "3B", "3E", "2A", "2B", "2E", "1A", "1B", "1E"}; // class indexing
    public static HashMap<String, Integer> classes_id = new HashMap<>();       // mapping of classes with indexing
    
    public static computeTimeTable _computeTimeTable = new computeTimeTable();
    public static output _output = new output();
    public static reCheck _reCheck = new reCheck();
    public static electives _electives = new electives();
    public static crossCheck _crossCheck = new crossCheck();
    public static checkValid _checkValid = new checkValid();
    public static input _input = new input();
    public static labs _labs = new labs();
    public static constructDS _constructDS = new constructDS();

    public static void generate() throws FileNotFoundException {
        Scanner sc = new Scanner(System.in);
        c = time.c;
        t = teachers.size();
      //  c = sc.nextInt();
       // t = sc.nextInt();
      //  it.add(6);
       // it.add(2);
        //ece.add(5);
        //ece.add(5);
        Pair mat[][] = new Pair[c][t];
        Pair mat1[][] = new Pair[c][t];

        out = new int[c][t][21];
        out1 = new String[c][t][21];
        lab = new int[c][t][5];

        int i, j;

        for (i = 0; i < c; i++) {
            for (j = 0; j < t; j++) {
                for (int k = 0; k < 21; k++) {
                    out[i][j][k] = 0;
                    out1[i][j][k] = "-";
                    if (k < 5) {
                        lab[i][j][k] = 0;
                    }
                }
            }
        }

        _constructDS.generateTeacherList();
        _input.generateMapping();
        _constructDS.generateMatrix(mat, mat1);
        _constructDS.buildTeacherMap();

        _constructDS.classes_to_id();
        _input.generateLabMap();
        _constructDS.buildTeacherLabMap();

//        for (String s : lab_map.keySet()) {
//            for (i = 0; i < lab_map.get(s).size(); i++) {
//                System.out.println(lab_map.get(s).get(i));
//            }
//        }
        _labs.allotLabs();

        for (i = 0; i < c; i++) {
            for (j = 0; j < t; j++) {
                if (mat[i][j] == null) {
                    mat[i][j] = new Pair(0, -1);
                    mat1[i][j] = new Pair(0, -1);
                }
//                System.out.print(mat[i][j].first + " ");
            }

//            System.out.println("");
        }

        _input.getElectives();
        _electives.addElectives();
//        compute(mat, 0);

        //  printCor();
        //compute(mat, 0);
        _electives.allotElectiveWish();
        _electives.allotReservedElectives(mat);
        _electives.onlyECE();
        //printOutput();
        _computeTimeTable.computeNew(mat, 0);
        //printOutput();
        //allotReservedElectives(mat);
        _reCheck.recheck(mat, 0);

        //allotCommon_core();
        _output.printOutput();
        _electives.allotExtraECE(mat);
        _output.teachList();

        _crossCheck.getOutput(mat);
        //printOutput_new();

        //System.out.println("helloworls");
        if (_checkValid.checkValid()) {
            System.out.println("-------------------All is well------------------------");
        } else {
            System.out.println("We are sorry :( , something bad happened. Please run the application again");
        }
        //checkValid();
    }
}